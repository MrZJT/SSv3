package Controller;

import Support.Warehouse;

public class AlertForWarehouse {
	static	Warehouse WX;
	

	}
