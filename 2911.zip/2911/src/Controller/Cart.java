package Controller;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import Support.Customer;
import Support.Database;
import Support.Product;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
public class Cart implements Initializable{
	 public static String info1;
	 public static String info2;
	 @FXML
	    private ListView<Product> CartList;

	
	    @FXML
	    private Button checkout;

	    @FXML
	    private Label TestLabel;

	    @FXML
	    private ComboBox<?> paymentchoicebox;

	    @FXML
	    private Button payvia;

	    @FXML
	    private Button select;

	    @FXML
	    private Button delete;

	    @FXML
	    private Button modifiy;

	    @FXML
	    private Button discount;

	    @FXML
	    void Deleteproductfromcart(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
	    	Product x=CartList.getSelectionModel().getSelectedItem();	
	    			///Database.GetDB().GetCD().get(info1).Cart.remove(Database.GetDB().GetCD().get(info1).Cart.get(i));
	    			
	    	Database.GetDB().GetCD().get(info1).Cart.remove(x);
	    			
	    			CartList.getItems().remove(CartList.getSelectionModel().getSelectedItem());
	    		
	    		
	    	
	    	
	    }

	    @FXML
	    void applyfordiscount(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
	    	Customer cust=Database.GetDB().GETCUST(info1, info2);
	    	String x=cust.PrivilegeCode;
	    	if(x.equals("A")) {
	    		cust.discount=10;
	    	}
	    	else {
	    		System.out.println("NO");
	    	}
	    }

	    @FXML
	    void modifiy(ActionEvent event) {

	    }
	    

		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			try {
				Customer Cusx=Database.GetDB().GETCUST(info1, info2);
				for(int i=0;i<Cusx.GetCart().size();i++) {
					this.CartList.getItems().add(Cusx.GetCart().get(i));
				}
			} catch (ClassNotFoundException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}

	 
	 
	 
	 
	 
}
