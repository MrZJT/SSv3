package Controller;

import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Map.Entry;

import Fix.FraudorNot;
import Support.Category;
import Support.Database;
import Support.Product;
import Support.Store;
import Support.Warehouse;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

public class LoadInventory implements Initializable{
	@FXML
	private TextField UnderCatsID;
	static Store SX=null;
	static Warehouse WX=null;
    
	
	@FXML
	TextField XID;
	
	@FXML
	private TreeView<Product> List;
	
    @FXML
    private Button Serial;

    @FXML
    private TextField Title;

    @FXML
    private TextField Price;
    @FXML
    private TextField Location;
    @FXML
    private TextField Stock;

    @FXML
    private Button AddProduct;
    @FXML
    private TextField D_ID;
    @FXML
    private TextField D_Price;
    @FXML
    private TextField D_Stock;
    
    @FXML
    private Button UpdationButton;
    @FXML
    void UpdateDetails(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {    	
    	Product x=Database.GetDB().FindProduct(D_ID.getText());
    	if(Integer.parseInt(D_Stock.getText())==x.GetStock()) {
    		
    		Database.GetDB().DeleteProduct(List.getSelectionModel().getSelectedItem().getValue());
    		List.getRoot().getChildren().remove(List.getSelectionModel().getSelectedItem());
    	}
    	x.setPrice(Integer.parseInt(D_Price.getText()));
    	x.SubStock(Integer.parseInt(D_Stock.getText()));
    	
    }
    public void mouseClick(MouseEvent mouseEvent) {
    	this.X=List.getSelectionModel().getSelectedItem();
    
    }
    TreeItem<Product> X;
    @FXML
    void AddProductToDB(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	String Title="//";
    	Integer PricePerUnit=0;
    	Integer Stock=0;
    	String CategoryID;
    	String Location="";
    	String UnderCats="";
    	if(this.Location!=null) {
    		Location=this.Location.getText();
    	}
    	
    	//String XID=XID.getTe
    	if(this.UnderCatsID.getText()!=null) {
    		UnderCats=this.UnderCatsID.getText();
    		System.out.println("this is undercat id!");
    	}
    	
    	if(this.Title.getText()!=null) {
    		Title=this.Title.getText();
    		if(this.Price.getText()!=null) {
    			PricePerUnit=Integer.valueOf(this.Price.getText());
    			if(this.Stock!=null) {
    				Stock=Integer.parseInt(this.Stock.getText());
    				System.out.println("ALL SET!");
    			}
    		}
    	}
    	Product x=new Product(Title);
    	TreeItem<Product> Product=new TreeItem<Product>(x);
    	x.setPrice(PricePerUnit);
    	x.AddToStock(Stock);
    	
    	
    	
    	
    	this.mouseClick(null);
    	//TreeItem<Product> StoreActProduct=this.X;
    	Store se=Database.GetDB().getStore(Location);
    
    	boolean flag=se.search(x);
    	if(flag==false) {
    	Database.GetDB().GetProducts().put(Title,x);
    		if(se.searchCats(UnderCats)==true) {
    			Category g=se.getCats(UnderCats);
    			g.ListOfProducts.add(x);
    			Database.GetDB().GetProducts().put(x.toString(), x);
    			this.initialize(null,null);
    		}
    		else {
    			se.createCnP(UnderCats,x);
    			this.initialize(null,null);
    		}
    		
    	//X.getChildren().add(Product); 
    	}
    	else {
    		this.labelone.setText("Cannot Add Product!");
    	}
    	

    	
    }
	

private Label labeltwo;
    @FXML
    public Label labelone;

    @FXML
    void Serial(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	FraudorNot NoFraud=new FraudorNot();
		ObjectOutputStream out=null;
		try {
			out=new ObjectOutputStream(
					new FileOutputStream("C:/Users/Josef Haydn/Desktop/xkcd.txt"));
			out.writeObject(NoFraud);
			
		}catch(EOFException e) {
			
		}
		finally {
			out.close();
		}
		System.out.println("WORKSS!!!!!!!");
    }
    
    
    public void AddProductsRec(Store REGSx) throws FileNotFoundException, ClassNotFoundException, IOException {
    	System.out.println("AAAAA!!");
    	Product X=new Product(REGSx.GetID());
    	TreeItem<Product> Store=new TreeItem<Product>(X);
    	this.List.getRoot().getChildren().add(Store);
    	
    		
    		Additions(REGSx.GetRoot(),Store);

    		
    }
    public void AddProductsRec(Warehouse REGWx) throws FileNotFoundException, ClassNotFoundException, IOException {

    	
    	
    	
    	Product X=new Product(REGWx.GetID());
    	TreeItem<Product> Warehouse=new TreeItem<Product>(X);
    	List.getRoot().getChildren().add(Warehouse);
    	Additions(REGWx.root,Warehouse);

    }
    
    
    
    public void Additions(Category Cats,TreeItem<Product> Item) {
    	Store store=new Store(null, null);
    	
    	if(Cats.End==true) {
    		for(int i=0;i<Cats.ListOfProducts.size();i++) {
    			TreeItem<Product> Addition=new TreeItem<Product>(Cats.ListOfProducts.get(i));
    			System.out.println("BBBLCC!!K");
    			Item.getChildren().add(Addition);
    		}
    	}
    	else {
    		if(Cats.ListOfProducts.size()!=0) {
    		for(int i=0;i<Cats.ListOfProducts.size();i++) {
    			Product Fake=new Product(Cats.ListOfProducts.get(i).toString());
    			TreeItem<Product> CatFake=new TreeItem<Product>(Fake);
    			Item.getChildren().add(CatFake);
    			Additions(Cats.ListOfSubCategories.get(i),CatFake);
    		}
    	}
    	}
    	
    }
    
    
    
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		Product root=new Product("/");
		TreeItem<Product> Root=new TreeItem<Product>(root);
		List.setRoot(Root);
					try {
						for (Entry<String, Store> entry : Database.GetDB().GetRS().entrySet()) {
							System.out.println("!DDDDDs!");
						try {
							AddProductsRec(entry.getValue());
						} catch (ClassNotFoundException | IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						try {
							for (Entry<String,Warehouse> entr : Database.GetDB().GetRW().entrySet()) {
								AddProductsRec(entr.getValue());
	}
						} catch (ClassNotFoundException | IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}




						}
					} catch (ClassNotFoundException | IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	}
	

		    	
	}

