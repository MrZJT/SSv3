package Controller;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;

import Fix.FraudorNot;
import Support.Admin;
import Support.Customer;
import Support.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginPage {
    @FXML
    private TextField UserName;
    @FXML
    private TextField Password;

    @FXML
    private Button LoginButton;

    @FXML
    void ReadInputs(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {

    	String Username=this.UserName.getText();
    	String Password=this.Password.getText();
    	int flag=0;
    	int KindOf=-111;;
    
    	Customer x=Database.GetDB().GetUser_C(Username, Password);
    	Admin xs=Database.GetDB().GetUser_A(Username,Password);
    	if(xs!=null) {
    		
    		Admin Admin=Database.GetDB().GetUser_A(Username,Password);
    		KindOf=Admin.type();
    		StoreGUI.info1=Admin.GETID();
    		StoreGUI.info2=Admin.GETPASSWORD();
    		flag=Admin.type();
    		System.out.println(flag);
    	
    	}
    	else {
    		Customer Customer=Database.GetDB().GetUser_C(Username,Password);
    		}
    	
    	
    	 if(KindOf==1){
    		try {
    			StoreAdminHome.SX=xs.store;
    			Stage Stage1=new Stage();
        		URL url=new File("C:/Users/Josef Haydn/Desktop/SuperUserMain.fxml").toURL();
    			
    			Parent root = FXMLLoader.load(url);
       			Scene scene1=new Scene(root);
    			Stage1.setScene(scene1);
    			Stage1.show();
    		} catch(Exception e) {
    			e.printStackTrace();
    		}
    		
    	}
    	else if(KindOf==0) {
    		try {
    			StoreAdminHome.SX=xs.store;
    			Stage Stage1=new Stage();
        		URL url=new File("C:/Users/Josef Haydn/Desktop/StoreAdminHome.fxml").toURL();
    			Parent root = FXMLLoader.load(url);
       			Scene scene1=new Scene(root);
    			Stage1.setScene(scene1);
    			Stage1.show();
    		} catch(Exception e) {
    			e.printStackTrace();
    		}
    		
    	}
    	else if(KindOf==-1) {
    		try {StoreAdminHome.SX=xs.store;
    			WarehouseAdminHome.warehouse=xs.whouse;
    			Stage Stage1=new Stage();
        		URL url=new File("C:/Users/Josef Haydn/Desktop/WarehouseHome.fxml").toURL();
    			Parent root = FXMLLoader.load(url);
       			Scene scene1=new Scene(root);
    			Stage1.setScene(scene1);
    			Stage1.show();
    		} catch(Exception e) {
    			e.printStackTrace();
    		}
    		try {
    			StoreAdminHome.SX=xs.store;
    			Stage Stage1=new Stage();
        		URL url=new File("C:/Users/Josef Haydn/Desktop/alert.fxml").toURL();
    			Parent root = FXMLLoader.load(url);
       			Scene scene1=new Scene(root);
    			Stage1.setScene(scene1);
    			Stage1.show();
    		} catch(Exception e) {
    			e.printStackTrace();
    		}
    		
    		
    		
    	}
    	else  {
     		try {
     			
     			StoreGUI.info1=Username;
     			StoreGUI.info2=Password;
     			Stage Stage1=new Stage();
         		URL url=new File("C:/Users/Josef Haydn/Desktop/mainscreen.fxml").toURL();
     			Parent root = FXMLLoader.load(url);
        			Scene scene1=new Scene(root);
     			Stage1.setScene(scene1);
     			Stage1.show();
     		} catch(Exception e) {
     			e.printStackTrace();
     		}
     	}
    
    }

}
