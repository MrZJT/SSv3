package Controller;

import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Map.Entry;

import Fix.FraudorNot;
import Support.Product;
import Support.Warehouse;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;

public class SWInventory implements Initializable{
	
    public static Warehouse WX;

	@FXML
    private TextField Title;

    @FXML
    private TextField Price;

    @FXML
    private TextField Stock;

    @FXML
    private Button AddProduct;

    @FXML
    private Button Serial;

    @FXML
    private TreeView<Product> List;

    @FXML
    private TextField UnderCatsID;

    @FXML
    void AddProductToDB(ActionEvent event) {

    }

    @FXML
    void Serial(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	FraudorNot NoFraud=new FraudorNot();
		ObjectOutputStream out=null;
		try {
			out=new ObjectOutputStream(
					new FileOutputStream("C:/Users/Josef Haydn/Desktop/xkcd.txt"));
			out.writeObject(NoFraud);
			
		}catch(EOFException e) {
			
		}
		finally {
			out.close();
		}
		System.out.println("WORKSS!!!!!!!");
    
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Product Root=new Product("/");
		TreeItem<Product> root=new TreeItem<>(Root);

		for(int i=0;i<WX.GetInventory().GetInventory().size();i++) {
			Product P=WX.GetInventory().GetInventory().get(i);
			TreeItem<Product> Item=new TreeItem<>();
			root.getChildren().add(Item);
		}
		List.setRoot(root);
	}

}
