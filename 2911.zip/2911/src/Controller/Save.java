package Controller;

import Support.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class Save {

    @FXML
    private Button SaveButton;

    @FXML
    private TextField TextField1;

    @FXML
    void ReadTextField(ActionEvent event) {
    	
    }

    @FXML
    void SaveTextFieldButton(ActionEvent event) {
    	
    }

}
