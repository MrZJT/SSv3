package Controller;

import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import Fix.FraudorNot;

import java.util.ResourceBundle;

import Support.Database;
import Support.Product;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.SwipeEvent;
import javafx.stage.Stage;

public class Screen implements Initializable{
	
	@FXML
    private TreeView<Product> TreeView;

	
	 static String info1;
	    static String info2;
	
    @FXML
    private Label labelone;
    
    @FXML
    private Button ViewButton;

    @FXML
    private Button DeleteButton;
    
    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
//		Product X=new Product("X");
//		X.AddToStock(1);
//		X.setPrice(11.00);
//		Product Y=new Product("Y");
//		Y.AddToStock(11);
//		Y.setPrice(111111.00);
//		Product Z=new Product("Z");
//		Z.AddToStock(133);
//		Z.setPrice(11333.00);
    	Product Root=new Product("X");
		TreeItem<Product> root=new TreeItem<>(Root);
//		TreeItem<Product> child1=new TreeItem<>(Y);
//		TreeItem<Product> child2=new TreeItem<>(Z);
  //  	root.getChildren().add(child1);
//		root.getChildren().add(child2);
	
		
		HashMap<String, Product> REGPx = null;
		try {
			REGPx = Database.GetDB().GetProducts();
			System.out.println("hello!");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Entry<String, Product> entry : REGPx.entrySet())  {
			Product P=entry.getValue();
			
			TreeItem<Product> Item=new TreeItem<>(P);
			root.getChildren().add(Item);
		}
		TreeView.setRoot(root);
		TreeView.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(final KeyEvent keyEvent) {
				
				final TreeItem<Product> SelectedItem=TreeView.getSelectionModel().getSelectedItem();
				if(SelectedItem!=null) {
					if(keyEvent.getCode().equals(KeyCode.DELETE)) {
						try {
							System.out.println(SelectedItem.getValue().toString());
							Database.GetDB().DeleteProduct(SelectedItem.getValue());
						} catch (ClassNotFoundException | IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						labelone.setText(SelectedItem.getValue().toString()+" Deleted!!");
						if(SelectedItem==TreeView.getRoot()) {
							System.out.println("BLEHTI!");
						}
						TreeView.getRoot().getChildren().remove(SelectedItem);
					}
					
				}
			}
		});
		
         }
    
    @FXML
    void ControlTreeView(ActionEvent event) {
    
    }
    
    @FXML
    void ViewItem(ActionEvent event) {
    	

    }
    																																																																																																																																																																																																																																																
    @FXML
    public void bleh(MouseEvent X) {
    
    	if(X.getClickCount()==2) {
    	TreeItem<Product> item=TreeView.getSelectionModel().getSelectedItem();
    	this.labelone.setText(item.getValue().getDetails());
    	 
    	}
    	
    }
    
    @FXML
    private Button close;
    
    @FXML
    void close(ActionEvent event) throws FileNotFoundException, IOException, ClassNotFoundException {
    	FraudorNot NoFraud=new FraudorNot();
		ObjectOutputStream out=null;
		try {
			out=new ObjectOutputStream(
					new FileOutputStream("C:/Users/Josef Haydn/Desktop/xkcd.txt"));
			out.writeObject(NoFraud);
			
		}catch(EOFException e) {
			
		}
		finally {
			out.close();
		}
		System.out.println("WORKSS!!!!!!!");
		
	
	//	Stage stage= (Stage) ((Node) event.getSource()).getScene().getWindow();
	//	stage.close();
		
		
    }
    

    @FXML
    void DeleteItem(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	TreeItem<Product> item=TreeView.getSelectionModel().getSelectedItem();
    	TreeView.getRoot().getChildren().remove(item);
    	Database.GetDB().GetProducts().remove(item.getValue());
    	this.labelone.setText("Delete Button works for!! "+item.getValue().getDetails());
    	
    }

}
