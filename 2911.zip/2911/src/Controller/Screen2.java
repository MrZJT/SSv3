package Controller;

import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;

import Fix.FraudorNot;
import Support.Database;
import Support.Product;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Screen2 {

    @FXML
    private TextField Title;
    
    
    static String info1;
    static String info2;
    
    @FXML
    private TextField PricePerUnit;

    @FXML
    private TextField Stock;

    @FXML
    private Button AddProductButton;
    
    @FXML
    private Button Loader;
    
    @FXML
    void AddProductToDB(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	String Title="//";
    	Integer PricePerUnit=0;
    	Integer Stock=0;
    	if(this.Title.getText()!=null) {
    		Title=this.Title.getText();
    		if(this.PricePerUnit.getText()!=null) {
    			PricePerUnit=Integer.valueOf(this.PricePerUnit.getText());
    			if(this.Stock!=null) {
    				Stock=Integer.valueOf(this.Stock.getText());
    			}
    		}
    	}
    	Product x=new Product(Title);
    	x.setPrice(PricePerUnit);
    	x.AddToStock(Stock);
    	//Database.GetDB().GetProducts().put(Title,x);
    	Database.GetDB().GetProducts().put(Title,x);

    	
    }
 
    
    @FXML
    void LoadScreen1(ActionEvent event) {
    	try {
			Stage Stage1=new Stage();
    		URL url = new File("C:/Users/Josef Haydn/Desktop/mainscreen.fxml").toURL();
			Parent root = FXMLLoader.load(url);
   			Scene scene1=new Scene(root);
			Stage1.setScene(scene1);
			Stage1.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
    }
    
    
    

}
