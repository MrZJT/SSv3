package Controller;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map.Entry;

import Support.Database;
import Support.Product;
import Support.Store;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TreeItem;
import javafx.stage.Stage;


	


public class StoreAdminHome {

	static Store SX;
	
    @FXML
    private Button CheckInv;

    @FXML
    private Button NoitifyWarehouse;

    @FXML
    private Button ReCalEOQs;

    @FXML
    private Button UpdateInv;

    @FXML
    private Button BrowseSuperStore;

    @FXML
    private Button SignOut;

    @FXML
    void BrowseSSasGuest(ActionEvent event) {

    }

    @FXML
    void CheckInv(ActionEvent event) {
    	LoadInventory.SX=this.SX;
		try {
			Stage Stage1=new Stage();
    		URL url=new File("C:/Users/Josef Haydn/Desktop/swinv.fxml").toURL();
			Parent root = FXMLLoader.load(url);
   			Scene scene1=new Scene(root);
			Stage1.setScene(scene1);
			Stage1.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void OpenInv(ActionEvent event) {
    	
    }

    @FXML
    void ReCalEOQs(ActionEvent event) {
    	
//    	dfixedcost
//    	hcarryingcost
//    	kdemain
    	for(int i=0;i<SX.GetInventory().GetInventory().size();i++) {
    		SX.GetInventory().GetInventory().get(i).CalculateEOQ();
    
    	}}

    @FXML
    ArrayList<Product> SendNotification(ActionEvent event) {
    	
    	ArrayList Jinx=new ArrayList<Product>();
    	int units = 0;
    	for(int i=0;i<SX.GetInventory().GetInventory().size();i++) {
        	double gtx=	SX.GetInventory().GetInventory().get(i).EOQ;

    		for(int j=0;j<SX.GetInventory().GetInventory().size();j++) {
    			if(SX.GetInventory().GetInventory().get(i).equals(SX.GetInventory().GetInventory().get(j))) {
    				units++;
    			}
    			
    		}
    		if(units<gtx) {
				for(int ix=0;ix<(int) gtx-units;ix++) {
					Jinx.add(SX.GetInventory().GetInventory().get(i));
				}
			}
    		
    }
    	
    	
    	SX.SendToWarehouse(Jinx);
    	return Jinx;
    	
    	
    }

    @FXML
    void Signmeout(ActionEvent event) {
    
    }

}
