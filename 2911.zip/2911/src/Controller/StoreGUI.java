package Controller;

import java.awt.List;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.Map.Entry;

import Fix.FraudorNot;
import Fix.PriceSort;
import Fix.rPriceSort;
import Support.Admin;
import Support.Customer;
import Support.Database;
import Support.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class StoreGUI implements Initializable {
    @FXML
    private AnchorPane MAINPANE;
	
	@FXML
    private Button close;
    @FXML
    private ChoiceBox<String> CHOICEBOX;
    
    static String info1;
    static String info2;
    
    static Customer cust;
   
    @FXML
    private ImageView Image;

    @FXML
    private ListView<Product> LIST;
    
    
   
	public void ASort() {
    	for(int a=0;a<this.ProductList.size();a++) {
    		System.out.print(this.ProductList.get(a).GetPrice()+" ");
    	}
    	int i;
    	int k;
    	int j;
    	for(i=1;i<this.ProductList.size();i++) {
    		k=this.ProductList.get(i).GetPrice();
    		j=i-1;
    		while(j>=0 && this.ProductList.get(j).GetPrice()>k) {
    			this.ProductList.add(j+1,this.ProductList.get(j));
    			j=j-1;
    			
    		}
    		this.ProductList.get(j+1).setPrice(k);
    		
    	}
    	System.out.println();
    	for(int a=0;a<this.ProductList.size();a++) {
    		System.out.print(this.ProductList.get(a).GetPrice()+" ");
    	}
    }
    
    
    ArrayList<Product> ProductList;
    public void SortList(String x) {
    	if(x.equals("High to Low")) {
    	Collections.sort(this.ProductList,new PriceSort());
    	}
    	else {
    		Collections.sort(this.ProductList,new rPriceSort());
    	}

    	SortIt(x);
    	
    }
    public void SortIt(String str) {
    	String x=this.CHOICEBOX.getValue();
    	this.LIST.getItems().clear();
    	for(int i=0;i<this.ProductList.size();i++) {	
    		this.LIST.getItems().add(this.ProductList.get(i));
    		System.out.println(this.ProductList.get(i).toString());
    	}
    	}
    
    @FXML
    private Button SortButton;
    
    @FXML
    void SortViaChoice(ActionEvent event) {
    	String x=this.CHOICEBOX.getValue();
    	SortList(x);
    }
    
    @FXML
    private TextField Search;

    @FXML
    private Button SearchButton;

    @FXML
    private Label DisplayLabel;

    
    @FXML
    private Button Cartx;

    @FXML
    private Button AddToCartButton;


    @FXML
    void OpenCart(ActionEvent event) {
    		Cart.info1="pop";
    		Cart.info2="lol";
    		try {
    			Stage Stage1=new Stage();
        		URL url=new File("C:/Users/Josef Haydn/Desktop/Carttest.fxml").toURL();
    			//URL url = new File("C:/Users/Josef Haydn/Desktop/screen1.fxml").toURL();
    			Parent root = FXMLLoader.load(url);
       			Scene scene1=new Scene(root);
    			Stage1.setScene(scene1);
    			Stage1.show();
    		} catch(Exception e) {
    			e.printStackTrace();
    		} 		 }

    @FXML
    private TextField Quantity;
    @FXML
    void AddToCart(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	Customer cust=Database.GetDB().GetCD().get(info1);
    	Cart.info1=info1;
    	Cart.info2=info2;
    	StoreGUI.cust=new Customer(Cart.info1);
    	
    	for(int i=0;i<Integer.parseInt(Quantity.getText());i++){
    		//System.out.println(LIST);
    	cust.GetCart().add(LIST.getSelectionModel().getSelectedItem());
    	}
    	//this.initialize(null, null);
    	this.Search.setText("Successful!" + LIST.getSelectionModel().getSelectedItem().toString());
    }

    @FXML
    void SearchAndDisplay(ActionEvent event) {
    	String ProductTobeDisplayed=this.Search.getText();
    	for(int i=0;i<this.LIST.getItems().size();i++) {
    		if(this.LIST.getItems().get(i).toString().equals(ProductTobeDisplayed)) {
    			this.DisplayLabel.setText(this.LIST.getItems().get(i).getDetails());
    			return;
    		}	
    	}
    }

    @FXML
    void SearchProduct(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	for(int i=0;i<Database.GetDB().GetProducts().size();i++) {
    		String Search=this.Search.getText();
    		Product p=Database.GetDB().FindProducts(Search);
    		this.DisplayLabel.setText(p.getDetails());
    	}
    }

    
  
    
    
    
    
    
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		try {
			this.cust=Database.GetDB().GETCUST(info1, info2);
		} catch (ClassNotFoundException | IOException e) {
	
			e.printStackTrace();
		}
		
		ChoiceBox<String> xkcd1=new ChoiceBox<String>();
		xkcd1.setValue("SORT PRODUCTS IN");
		this.CHOICEBOX.getItems().addAll(FXCollections.observableArrayList("High","Low","Stock"));
	
		
		
		
		HashMap<String, Product> REGPx = null;
	
			try {
				REGPx = Database.GetDB().GetProducts();
			} catch (ClassNotFoundException | IOException e) {
			
				e.printStackTrace();
			}

			
		// languages: Hindi,German,English
		//blind:
		
		this.ProductList=new ArrayList<Product>();
		for (Entry<String, Product> entry : REGPx.entrySet())  {
			Product P=entry.getValue();
			this.ProductList.add(P);

			this.LIST.getItems().add(P);
			System.out.println(this.LIST.getItems().get(0) + " Hi");
			this.LIST.setVisible(true);
	
			System.out.println(P.toString());

		}
	
		
		
	}

    @FXML
    void closesuperstore(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	FraudorNot NoFraud=new FraudorNot();
		ObjectOutputStream out=null;
		try {
			out=new ObjectOutputStream(
					new FileOutputStream("C:/Users/Josef Haydn/Desktop/xkcd.txt"));
			out.writeObject(NoFraud);
			
		}catch(EOFException e) {
			
		}
		finally {
			out.close();
		}
		System.out.println("jinx");
    }
    

}
