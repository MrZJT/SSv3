package Controller;

import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.Map.Entry;

import Fix.FraudorNot;
import Support.Admin;
import Support.Database;
import Support.Product;
import Support.Store;
import Support.Warehouse;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SuperUserController implements Initializable{

	
	
	HashMap<String,Store> ListOfStores;
	HashMap<String,Warehouse> ListOfWarehouses;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    @FXML
    private Button Serialise;
	
	@FXML
    void Serialise(ActionEvent event) throws IOException, ClassNotFoundException {
		FraudorNot NoFraud=new FraudorNot();
		ObjectOutputStream out=null;
		try {
			out=new ObjectOutputStream(
					new FileOutputStream("C:/Users/Josef Haydn/Desktop/xkcd.txt"));
			out.writeObject(NoFraud);
			
		}catch(EOFException e) {
			
		}
		finally {
			out.close();
		}
		System.out.println("WORKSS!!!!!!!");
    }
	
	
	
    @FXML
    private Button ManageStoresAndWarehouses;

    @FXML
    private Button SignOut;

    @FXML
    private ComboBox<Store> ChooseStore;

    @FXML
    private ComboBox<Warehouse> ChooseWarehouse;

    @FXML
    private Button LINKBUTTON;

    @FXML
    private Button CreateStore;

    @FXML
    private TextField Create_StoreLocation;

    @FXML
    private TextField Create_StoreAdminID;

    @FXML
    private TextField Create_StoreID;

    @FXML
    private PasswordField Create_StoreAdminPassword;

    @FXML
    private TextField Create_WarLocation;

    @FXML
    private Button CreateWarehouse;

    @FXML
    private TextField Create_WarID;

    @FXML
    private TextField Create_WarAdminID;

    @FXML
    private PasswordField Create_WarAdminPassword;

    @FXML
    private TextField InventoryCheckLocationID;

    @FXML
    private Button CheckINVButton;

    @FXML
    void CreateStore(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	String SAdminID=this.Create_StoreAdminID.getText();
    	String SLocation=this.Create_StoreLocation.getText();
    	String SID=this.Create_StoreID.getText();
    	String sPswrd=this.Create_StoreAdminPassword.getText();
    	Admin sAdmin=new Admin(SAdminID, sPswrd);
    	sAdmin.SetKind("0");
    	
    	Store store=new Store(SID,sAdmin);
    	Database.GetDB().GetRS().put(SID, store);
    	Database.GetDB().GetAD().put(SAdminID, sAdmin);
    	Store se=Database.GetDB().getStore(SID);
    	this.ChooseStore.getItems().add(store);
    	System.out.println(sAdmin.AdminID);
    	System.out.println(sAdmin.type());
    	sAdmin.store=store;
    	
    	
    }

    @FXML
    void CreateWarehouse(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	String wAdminID=this.Create_WarAdminID.getText();
    	String wLocation=this.Create_WarLocation.getText();
    	String wID=this.Create_WarID.getText();
    	String wPswrd=this.Create_WarAdminPassword.getText();
    	Admin wAdmin=new Admin(wAdminID, wPswrd);
    	wAdmin.SetKind("-1");
    	Warehouse war=new Warehouse(wID,wAdmin);
    	Database.GetDB().GetRW().put(wID, war);
    	Database.GetDB().GetAD().put(wAdminID, wAdmin);
    	this.ChooseWarehouse.getItems().add(war);
    	wAdmin.whouse=war;

    	System.out.println(wAdmin.AdminID);
    }

    @FXML
    void GoToLoginScreen(ActionEvent event) {

    }

    @FXML
    void LinkStore2Warehouse(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	Store y=Database.GetDB().GetRS().get(this.ChooseStore.getValue().GetID());
    	System.out.println("YOLO!!!");
    	y.Link(Database.GetDB().GetRW().get(this.ChooseWarehouse.getValue().GetID()));
    	System.out.println("HHHHH");
    	//.Link(Database.GetDB().GetRW().get(this.ChooseWarehouse.getValue()));
    }

    @FXML
    void OpenAllWarehousesAndStoresLists(ActionEvent event) {
    	
    }

    @FXML
    void OpenLocationINV(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	String LocationX=this.InventoryCheckLocationID.getText();
    	System.out.println(LocationX);
    	System.out.println("hereee1!!");
    	Store x=Database.GetDB().getStore(LocationX);
    	Warehouse x1=Database.GetDB().getWarhouse(LocationX);
    	if(LocationX.charAt(0)=='s') {
    		System.out.println("Comeoverhere!");
    		LoadInventory.SX=Database.GetDB().getStore(LocationX);
    		try {
    			Stage Stage1=new Stage();
        		URL url=new File("C:/Users/Josef Haydn/Desktop/invbysuperuser.fxml").toURL();
    			Parent root = FXMLLoader.load(url);
       			Scene scene1=new Scene(root);
    			Stage1.setScene(scene1);
    			Stage1.show();
    		} catch(Exception e) {
    			e.printStackTrace();
    		}
    	}
    	else if(LocationX.charAt(0)=='w') {
    		Warehouse WX=Database.GetDB().getWarhouse(LocationX);
    		try {
    			Stage Stage1=new Stage();
        		URL url=new File("C:/Users/Josef Haydn/Desktop/invbysuperuser.fxml").toURL();
    			Parent root = FXMLLoader.load(url);
       			Scene scene1=new Scene(root);
    			Stage1.setScene(scene1);
    			Stage1.show();
    		} catch(Exception e) {
    			e.printStackTrace();
    		}
    	}
    }
 
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		try {
			this.ListOfStores=Database.GetDB().GetRS();
			this.ListOfWarehouses=Database.GetDB().GetRW();
			for (Entry<String, Store> entry : this.ListOfStores.entrySet()) {
				this.ChooseStore.getItems().add(entry.getValue());
			}
			for (Entry<String,Warehouse> entry: this.ListOfWarehouses.entrySet()) {
				this.ChooseWarehouse.getItems().add(entry.getValue());
			}
			
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}

}
