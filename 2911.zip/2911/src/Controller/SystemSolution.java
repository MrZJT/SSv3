package Controller;

import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.URL;

import Fix.FraudorNot;
import Support.Admin;
import Support.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SystemSolution {

    @FXML
    private Button InitiateSS;

    static String info1;
    static String info2;
    
    @FXML
    private TextField SUserName;

    @FXML
    private TextField SPassword;

    @FXML
    void InitiateSS(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	
    	System.out.println(SUserName.getText());

    	System.out.println(SPassword.getText());
    	//Database.GetDB().GetLD().put(SUserName.getText(),SPassword.getText());
    	Admin MrX=new Admin(SUserName.getText(),SPassword.getText());
    	MrX.SetKind("SuperUser");
    	MrX.SetKind("1");
    	Database.GetDB().GetAD().put("SuperUser", MrX);
    	//System.out.println(x);
    	FraudorNot NoFraud=new FraudorNot();
		ObjectOutputStream out=null;
		try {
			out=new ObjectOutputStream(
					new FileOutputStream("C:/Users/Josef Haydn/Desktop/xkcd.txt"));
			out.writeObject(NoFraud);
			
		}catch(EOFException e) {
			
		}
		finally {
			out.close();
		}
		System.out.println("WORKSS!!!!!!!");
    }

}
