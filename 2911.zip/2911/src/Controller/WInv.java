package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Map.Entry;

import Support.Database;
import Support.Product;
import Support.Warehouse;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;

public class WInv implements Initializable{
	
	@FXML
    private Button Serial;

    @FXML
    private TreeView<Warehouse> List;

    @FXML
    void Serial(ActionEvent event) {

    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		Warehouse rooxt=null;
		try {
			rooxt = new Warehouse(null, null);
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		TreeItem root1=new TreeItem<Warehouse>(rooxt);
		try {
			for (Entry<String, Warehouse> entry : Database.GetDB().GetRW().entrySet())  {
				Warehouse P=entry.getValue();
			
				TreeItem Item=new TreeItem<>(P);
				root1.getChildren().add(Item);
			}
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List.setRoot(root1);
		
		
		
		
	}

	
}
