package Controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.Map.Entry;
import java.util.ResourceBundle;

import Support.Admin;
import Support.Database;
import Support.Product;
import Support.Warehouse;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.stage.Stage;

public class WarehouseAdminHome{
	
	static Warehouse warehouse;
	static Admin wAdmin;
	
    @FXML
    private Button CheckAlterMessages;

    @FXML
    private Button ProcessOrder;

    @FXML
    private Button Inventory;

    @FXML
    private Button CheckHistory;

    @FXML
    private TextField EnterWarehouseID;

    @FXML
    private Button CheckOtherWarehouses;

    @FXML
    private Button CheckInventory;
    
    
    @FXML
    void CheckInventory(ActionEvent event) {
    	SWInventory.WX=warehouse;
    	
    	
    	try {
    		SWInventory.WX=warehouse;
			Stage Stage1=new Stage();
    		URL url=new File("C:/Users/Josef Haydn/Desktop/swinv.fxml").toURL();
			Parent root = FXMLLoader.load(url);
   			Scene scene1=new Scene(root);
			Stage1.setScene(scene1);
			Stage1.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void CheckOtherWarehouses(ActionEvent event) throws FileNotFoundException, ClassNotFoundException, IOException {
    	String wID=this.EnterWarehouseID.getText();
    	
    	try {
    		LoadInventory.WX=warehouse;
			Stage Stage1=new Stage();
    		URL url=new File("C:/Users/Josef Haydn/Desktop/WInv.fxml").toURL();
			Parent root = FXMLLoader.load(url);
   			Scene scene1=new Scene(root);
			Stage1.setScene(scene1);
			Stage1.show();
    		
		} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void LoadMessage(ActionEvent event) {

    	try {
    		//LoadInventory.WX=Database.GetDB().GetRW().get(wID);
			Stage Stage1=new Stage();
    		URL url=new File("C:/Users/Josef Haydn/Desktop/swinv.fxml").toURL();
			Parent root = FXMLLoader.load(url);
   			Scene scene1=new Scene(root);
			Stage1.setScene(scene1);
			Stage1.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void ProcessOrders(ActionEvent event) {
    	this.warehouse.ProcessOrders();
    }

	

}
