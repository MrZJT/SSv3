package Fix;

import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;

import Support.Admin;
import Support.Customer;
import Support.Database;
import Support.Product;
import Support.Store;
import Support.Warehouse;



public class FraudorNot implements Serializable{
	private HashMap<String,String> LoginDetails;
	private HashMap<String,Customer> RegisteredCustomers;
	private HashMap<String,Admin> RegisteredAdmins;
	private HashMap<String,Product> RegisteredProducts;
	private HashMap<String,Store> RegisteredStores;
	private HashMap<String,Warehouse> RegisteredWarehouse;
	public FraudorNot() throws FileNotFoundException, ClassNotFoundException, IOException {
		this.RegisteredProducts=Database.GetDB().GetProducts();
		this.LoginDetails=Database.GetDB().GetLD();
		this.RegisteredAdmins=Database.GetDB().GetAD();
		this.RegisteredCustomers=Database.GetDB().GetCD();
		this.RegisteredStores=Database.GetDB().GetRS();
		this.RegisteredWarehouse=Database.GetDB().GetRW();
		
	}
	public HashMap<String,Store> GetREGSx(){
		return this.RegisteredStores;
	}
	public HashMap<String,Warehouse> GetREGWx(){
		return this.RegisteredWarehouse;
	}
	public HashMap<String,String> GetLD(){
		return this.LoginDetails;
	}
	public HashMap<String,Product> GetREGPx(){
		return this.RegisteredProducts;
	}
	public HashMap<String,Admin> GetREGAx(){
		return this.RegisteredAdmins;
	}
	public HashMap<String,Customer> GetREGCx(){
		return this.RegisteredCustomers;
	}
	
	


}
