package Fix;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Load {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		FraudorNot NoFraud=new FraudorNot();
		ObjectInputStream in=null;
		try {
			in=new ObjectInputStream(
					new FileInputStream("C:/Users/Josef Haydn/Desktop/xkcd.txt"));
			FraudorNot Fraud=(FraudorNot) in.readObject();
		}catch(EOFException e) {
			
		}
		finally {
			in.close();
		}
	}
	
	
}
