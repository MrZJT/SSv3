package Fix;

import java.io.Serializable;
import java.util.Comparator;

import Support.Product;

public class rPriceSort implements Comparator<Product>,Serializable{

	@Override
	public int compare(Product one, Product two) {
		// TODO Auto-generated method stub
	
		//return one.GetPrice()-two.GetPrice();
		return two.GetPrice()-one.GetPrice();
	}

}