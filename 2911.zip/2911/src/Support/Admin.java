package Support;

import java.io.Serializable;

public class Admin implements Serializable{
	
	String KindOfAdmin="";
	public String AdminID="";
	String Username="";
	String Password="";
	public Warehouse whouse;
	public Store store;
	public Admin(String ID,String Password) {
		this.Username=ID;
		this.AdminID=ID;
		
		this.Password=Password;
	}
	
	public String GETID() {
		// TODO Auto-generated method stub
		return Username;
	}
	public String GETPASSWORD() {
		return Password;
	}
	public int type() {
		// TODO Auto-generated method stub
		if(KindOfAdmin.equals("1")) {
			return 1;
		}
		else if(KindOfAdmin.equals("-1")) {
			return -1;
		}
		else if(KindOfAdmin.equals("0")) {
			return 0;
		}
		else {
			return 8;
		}
		
		
	}
	public void SetKind(String kind) {
		this.KindOfAdmin=kind;
	}
}
