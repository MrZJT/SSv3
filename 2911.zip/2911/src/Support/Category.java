package Support;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

public class Category implements Serializable{
	
	private String Title;
	private Category Root;
	public ArrayList<Product> ListOfProducts;
	public boolean End;
	public ArrayList<Category> ListOfSubCategories;
	public String ID;
	public Category(String Title,String ID) {
		this.Title=Title;
		this.ListOfProducts=new ArrayList<Product>();
		this.ListOfSubCategories=new ArrayList<Category>();
		this.End=false;
		this.ID=ID;
	}
	public String GetTitle() {
		return this.Title;
	}
	public Category GetParent() {
		return this.Root;
	}
	public Product GetProduct(String ProductTitle) {
		for(int i=0;i<ListOfProducts.size();i++) {
			if(ListOfProducts.get(i).toString().equals(ProductTitle)) {
				return ListOfProducts.get(i);
			}
		}
		
		return null;
	}
	
	public boolean HasProduct(String ProductTitle) {
		for(int i=0;i<ListOfProducts.size();i++) {
			if(ListOfProducts.get(i).toString().equals(ProductTitle)) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public boolean equals(Object x) {
		if(x!=null && x.getClass()==this.getClass()) {
			Category z=(Category) x;
			return this.Title==z.Title && this.Root.Title==z.Root.Title;
		}
		else {
			return false;
		}
	}
	
	
	public boolean HasProduct(Product product) {
		for(int i=0;i<ListOfProducts.size();i++) {
			if(ListOfProducts.get(i).equals(product)) {
				return true;
			}
		}
		return false;
	}
	
}
