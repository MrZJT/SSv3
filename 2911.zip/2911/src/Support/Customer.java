package Support;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class Customer implements Serializable{
	public String CustomerID="";
	public String Password="";
	public ArrayList<Product> Cart;
	public String PrivilegeCode;
	public int discount;
	public Customer(String CustomerID) {
		this.CustomerID=CustomerID;
		this.Cart=new ArrayList<Product>();
		this.Password="";
	
	}
	public void SetPC(String PC) {
		this.PrivilegeCode=PC;
	}
	public void AddToCart(Product X) {
	this.Cart.add(X);
	}
	public String GETCUSTID() {
		return this.CustomerID;
	}
	public ArrayList<Product> GetCart(){
		return this.Cart;
	}
	public String GETCUSTCODE() {
		return this.Password;
	}
}
