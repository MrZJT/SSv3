package Support;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import Fix.FraudorNot;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;

public class Database implements Serializable{
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private static Database database;
		private HashMap<String,String> LoginDetails;
		private HashMap<String,Product> RegisteredProducts;
		private Database(String B) {}
		private HashMap<String,Customer> RegisteredCustomers;
		private HashMap<String,Admin> RegisteredAdmins;
		private HashMap<String,Store> RegisteredStores;
		private HashMap<String,Warehouse> RegisteredWarehouse;
		
		public static Database GetDB() throws FileNotFoundException, IOException, ClassNotFoundException {
			if(database==null) {
				ObjectInputStream in=null;
				try {
					System.out.println("he!!re in try");
					in=new ObjectInputStream(
							new FileInputStream("C:/Users/Josef Haydn/Desktop/xkcd.txt"));
					
					
					FraudorNot Fr=(FraudorNot) in.readObject();
					Database.database=new Database("X");
					Database.database.setDB(Fr);
					
				
				}catch(EOFException e) {
					Database.database=new Database("X");
					Database.database.LoginDetails=new HashMap<String,String>();
					Database.database.RegisteredProducts=new HashMap<String,Product>();
					Database.database.RegisteredAdmins=new HashMap<String,Admin>();
					Database.database.RegisteredCustomers=new HashMap<String,Customer>();
					Database.database.RegisteredStores=new HashMap<String,Store>();
					Database.database.RegisteredWarehouse=new HashMap<String,Warehouse>();
					System.out.println("Jked!");
					return database;
				}
				finally {
					if(in!=null) {
					in.close();
					}
				}
			}
			//System.out.println("LOLLL!");
			return database;
		}
		public void setDB(FraudorNot Fr) throws FileNotFoundException, ClassNotFoundException, IOException {
			// TODO Auto-generated method stub
			System.out.println("hello!s");
			Database.database=new Database("ZZ!");
			System.out.println("TEN FEET FOOOT!");
			Database.GetDB().LoginDetails=Fr.GetLD();
			Database.GetDB().RegisteredProducts=Fr.GetREGPx();
			Database.GetDB().RegisteredAdmins=Fr.GetREGAx();
			Database.GetDB().RegisteredCustomers=Fr.GetREGCx();
			Database.GetDB().RegisteredStores=Fr.GetREGSx();
			Database.GetDB().RegisteredWarehouse=Fr.GetREGWx();
			
		}

		public HashMap<String,String> GetLD(){
			return this.LoginDetails;
		}
		
		public HashMap<String,Product> GetProducts(){
			return this.RegisteredProducts;
		}
		
		public void AddProduct(String Title,Product X) {
			this.RegisteredProducts.put(Title,X);
		}
		
		public void DeleteProduct(Product X) throws FileNotFoundException, ClassNotFoundException, IOException {
			boolean xk=Database.GetDB().GetProducts().containsKey(X.Title);
			System.out.println(xk);
			Database.GetDB().GetProducts().remove(X.Title, X);
			boolean xk2=Database.GetDB().GetProducts().containsKey(X.Title);
			System.out.println(xk2);
		}
		public Customer GetUser_C(String Username,String Password) {
			//return null;
			// TODO Auto-generated method stub
		for (Entry<String, Customer> X: this.RegisteredCustomers.entrySet()) {
			if(X.getValue().GETCUSTID().equals(Username)
					&& X.getValue().GETCUSTCODE().equals(Password)) {
				return X.getValue();
			}
		}
		return null;
			
		}
		public Admin GetUser_A(String Username,String Password) {
			for (Entry<String, Admin> X: this.RegisteredAdmins.entrySet()) {
				if(X.getValue().GETID().equals(Username)
						&& X.getValue().GETPASSWORD().equals(Password)) {
					return X.getValue();
				}
			}
			return null;
			
		}
		public Customer GETCUST(String Username, String Password) {
			for (Entry<String, Customer> X: this.RegisteredCustomers.entrySet()) {
				if(X.getValue().GETCUSTID().equals(Username)
						&& X.getValue().GETCUSTCODE().equals(Password)) {
					return X.getValue();
				}
			}
			return null;
			
		}
		public HashMap<String, Admin> GetAD() {
			// TODO Auto-generated method stub
				return this.RegisteredAdmins;
		}
		public HashMap<String, Customer> GetCD() {
			// TODO Auto-generated method stub
			return this.RegisteredCustomers;
		}
		public HashMap<String, Store> GetRS() {
			// TODO Auto-generated method stub
			return this.RegisteredStores;
		}
		public HashMap<String, Warehouse> GetRW() {
			// TODO Auto-generated method stub
			return this.RegisteredWarehouse;
		}
		public Store getStore(String locationX) {
			// TODO Auto-generated method stub
			for (Entry<String, Store> entry : this.RegisteredStores.entrySet()){
				if(entry.getValue().GetID().equals(locationX)) {
					return entry.getValue();
				}
			}
			return null;
			
		}
		public Warehouse getWarhouse(String locationX) {
			// TODO Auto-generated method stub
			for (Entry<String, Warehouse> entry : RegisteredWarehouse.entrySet())  {
				if(entry.getValue().GetID().equals(locationX)) {
					return entry.getValue();
				}
			}
			return null;
		}
		public Product FindProduct(String d_ID) throws FileNotFoundException, ClassNotFoundException, IOException {
			// TODO Auto-generated method stub
			return Database.GetDB().GetProducts().get(d_ID);
		}
		public Product FindProducts(String search) {
			// TODO Auto-generated method stub
			for (Entry<String, Product> entry : this.RegisteredProducts.entrySet())  {
				if(entry.getValue().toString().equals(search)) {
					return entry.getValue();
				}
			}
			return null;
		}
		
	
		
//		public void SetUser(String username, String password) {
//			// TODO Auto-generated method stub
//			if(username.charAt(0)=='9') {
//				for (Entry<String, Admin> entry : this.RegisteredAdmins.entrySet()) {
//					
//				}
//				
//				Admin CurrentAdminLoggedIn=this.Re
//				
//				
//			}
//			else {
//				for (Entry<String, Admin> entry : this.RegisteredAdmins.entrySet()) {
//					
//				}
//				
//			}
//			
//		}
	 
	

}
