package Support;

import java.io.Serializable;

public class Engine implements Serializable{
	private static Engine engine;
	private Database database;
	private Engine() {
		
	}

}
