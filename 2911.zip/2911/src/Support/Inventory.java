package Support;

import java.io.Serializable;
import java.util.ArrayList;

public class Inventory implements Serializable {
	ArrayList<Product> ProductList;
	public void SetInventory() {
		this.ProductList=new ArrayList<Product>();
	}
	public ArrayList<Product> GetInventory(){
		return this.ProductList;
	}
	public Product GetProduct(String Title) {
		return null;
		
	}
	
	public void AddProduct(Product x) {
		this.ProductList.add(x);
	}
	public Inventory() {
		this.ProductList=new ArrayList<Product>();
	}
}
