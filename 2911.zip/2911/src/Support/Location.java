package Support;

import java.io.Serializable;

public class Location implements Serializable{

}
