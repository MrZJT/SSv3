package Support;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class Notifier implements Serializable{
	private ArrayList<Product> Order;
	public Notifier(ArrayList<Product> Order) {
		this.Order=new ArrayList<Product>(Order);
	}
	public ArrayList<Product> GetNotice(){
		return this.Order;
	}
}
