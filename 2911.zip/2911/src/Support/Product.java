package Support;

import java.io.Serializable;

public class Product implements Serializable,Comparable<Product>{
	public String Title;
	public String ID;
	public Integer inStock;
	public Integer PricePerUnit;
	public Category DirectParent;
	public Integer D;
	public Integer H;
	public Integer K;
	public Integer Demand;
	public void inDemand() {
		this.K=this.K+1;
	}
	public void SetD(Integer x) {
		this.D=x;
		
	}
	public void SetK(Integer x) {
		this.K=x;
	}
	public void SetH(Integer x) {
		this.H=H;
	}
	public void CalculateEOQ() {
		this.EOQ=(double) (double) 2*this.D*this.K/(double) this.H ;
	}
	public Double EOQ;
	
	public Integer GetPrice() {
		return this.PricePerUnit;
	}
	public Integer GetStock() {
		return this.inStock;
	}
	
	public Product(String Title){
		this.Title=Title;
		this.PricePerUnit=1;
		this.inStock=0;
	}
	@Override
	public String toString() {
		return this.Title;
	}
	@Override
	public boolean equals(Object x) {
		if(x!=null && x.getClass()==this.getClass()) {
			Product xx=(Product) x;
			return this.ID==xx.ID;
		}
		else {
			return false;
		}
	}
	
	@Override
	public int compareTo(Product x) {
		if(this.GetPrice()>x.GetPrice()) {
			return 1;
		}
		else if(this.GetPrice()<x.GetPrice()) {
			return -1;
		}
		else {
			return 0;
		}
	}
	public String getDetails() {
		return "Product Name: " + Title + " In Stock Items:"+ this.inStock+ " Price Per Unit"+ 
				this.PricePerUnit;
	}
	public void setPrice(Integer PPU) {
		this.PricePerUnit=PPU;
	}
	public void AddToStock(int Quantity) {
		this.inStock=this.inStock+Quantity;
	}
	public void SubStock(int i) {
		// TODO Auto-generated method stub
		this.inStock=this.inStock-i;
		
	}
	
}
