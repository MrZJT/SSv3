package Support;

import java.io.Serializable;
import java.util.ArrayList;

import javafx.scene.control.TextField;

public class Store implements Serializable{
	private String StoreID;
	private Admin StoreAdmin;
	private Warehouse LinkedWarehouse=null;
	private Inventory sInventory;
	private Location Location;
	private Notifier sNotifier;
	public Category Root;
	public Category GetRoot() {
		return this.Root;
		
	}
	public String toString() {
		return this.GetID();
	}
	
	public Store(String StoreID,Admin StoreAdmin) {
		this.StoreAdmin=StoreAdmin;
		this.StoreID=StoreID;
		this.sInventory=new Inventory();
		this.Root=new Category("root",this.StoreID);
	}
	public void Link(Warehouse MyWarehouse) {
		this.LinkedWarehouse=MyWarehouse;
	}
	public Admin GetADMIN() {
		return this.StoreAdmin;
	}

	public Warehouse GetLinkedWarehouse() {
		return LinkedWarehouse;
		
	}
	public Inventory GetInventory() {
		return sInventory;
		
	}
	public Notifier GetNotifier() {
		return this.sNotifier;
	}
	public Location GetLocation() {
		return Location;
		
	}
	public String GetID() {
		// TODO Auto-generated method stub
		return this.StoreID;
	}

	public boolean search(Product x) {
		// TODO Auto-generated method stub
		System.out.println("in here!!");
		return this.search(Root,x);
	}

	private boolean search(Category root, Product x) {
		// TODO Auto-generated method stub
		
		if(root.End==true) {
			for(int i=0;i<root.ListOfProducts.size();i++) {
				if(root.ListOfProducts.get(i).equals(x)) {
					return true;
				}
			}
		}
		else {
			System.out.println("MIMIMSIMSIMSISMISMISMISMSIMIS");
			for(int i=0;i<root.ListOfSubCategories.size();i++) {
					this.search(root.ListOfSubCategories.get(i),x);
				}
			return false;
		}
		
		return false;

	
	}
	public boolean searchCats(String X) {
		return this.searchCats(this.Root,X);
	}
	public boolean searchCats(Category root,String X) {
		if(root.ID.equals(X)) {
			return true;
		}
		else {
			for(int i=0;i<root.ListOfSubCategories.size();i++) {
					this.searchCats(root.ListOfSubCategories.get(i),X);
				}
			return false;
		}
		
	
		
	}

	public void createCnP(String underCatsID, Product x) {
		// TODO Auto-generated method stub
		Category li=new Category(underCatsID,underCatsID);
		this.Root.ListOfSubCategories.add(li);
		li.ListOfProducts.add(x);
	}

	public Category getCats(String text) {
		// TODO Auto-generated method stub
		return this.searchCatsRT(this.Root,text);
	}
	public Category searchCatsRT(Category root,String X) {
		if(root.ID.equals(X)) {
			return root;
		}
		else {
			for(int i=0;i<root.ListOfSubCategories.size();i++) {
					this.searchCats(root.ListOfSubCategories.get(i),X);
				}
			return null;
		}
		
	
		
	}
	public void SendToWarehouse(ArrayList jinx) {
		// TODO Auto-generated method stub
		this.LinkedWarehouse.OrderToBeProcessed=jinx;
	}
	
}

