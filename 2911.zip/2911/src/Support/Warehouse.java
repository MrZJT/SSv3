package Support;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class Warehouse implements Serializable{
	private String wID;
	public ArrayList<Product> OrderToBeProcessed;
	public Store OrderFrom;
	public Category root;
	private Admin wAdmin;
	private Store Store=null;
	private ArrayList<Warehouse> wList;
	private Inventory wInventory;
	private Location wLocation;
	private Notifier wNotifier;
	public Warehouse(String ID,Admin wAdmin) throws FileNotFoundException, ClassNotFoundException, IOException {
		this.wList=new ArrayList<Warehouse>();
		this.wInventory=new Inventory();
		this.wLocation=new Location();
		this.wID=ID;
		this.wAdmin=wAdmin;
		
		//this.wNotifier=new Notifier();
		for(int i=0;i<Database.GetDB().GetRW().size();i++) {
			this.wList.add(Database.GetDB().GetRW().get(i));
		}
	}
	
	public Admin GetADMIN() {
		return this.wAdmin;
	}
	 
	public ArrayList<Warehouse> GetAssociatedWs(){
		return this.wList;
		
	}
	public Inventory GetInventory() {
		return wInventory;
		
	}
	public Notifier GetNotifier() {
		return this.wNotifier;
	}
	public Location GetLocation() {
		return this.wLocation;
		
	}
	public boolean CanServe(Notifier other) {
		this.wNotifier=other;
		ArrayList<Product> Extras=this.CheckInventory(other);
		boolean Canserve=false;
		if(Extras.size()==0) {
			Canserve=true;
			return Canserve;
		}
		else {
			Canserve=false;
			ArrayList<Integer> EVLWTHN=AskOtherWarehouses(Extras);
			for(int i=0;i<EVLWTHN.size();i++) {
				if(EVLWTHN.get(i)==-1) { 
					return Canserve;
				}
			}

			return true;
		}
		
	}

	private ArrayList<Integer> AskOtherWarehouses(ArrayList<Product> extras) {
		ArrayList Gotit=new ArrayList<Integer>();
		int counter=0;
		int loaded=0;
		for(int i=0;i<extras.size();i++) {
			for(int j=0;j<this.wList.size();j++) {
				if(loaded==extras.get(i).GetStock()) {
					Gotit.add(i, 1);
					break;
				}
				int quantity=DoesItHaveItSufficientQuantity(this.wList.get(j),extras.get(i));
				int quantityx;
				if(quantity!=-1) {
				if(quantity==extras.get(i).GetStock() || quantity>extras.get(i).GetStock()) {
					this.wList.get(i).BuyStuff(extras.get(i),this.wList.get(i));
					loaded+=extras.get(i).GetStock();
					extras.get(i).SubStock(quantity);
					counter++;
				}
				else {
					this.wList.get(i).BuyStuff(extras.get(i),this.wList.get(i));
					loaded+=quantity;
					extras.get(i).SubStock(quantity);
				}
				
				}
				
			}
			if(loaded!=extras.get(i).GetStock()) {
				Gotit.add(i,-1);
			}
			else {
				Gotit.add(i,1);
			}
			
		}
		// TODO Auto-generated method stub
		
		return Gotit;
		
	}

	private void BuyStuff(Product product, Warehouse warehouse) {
		// TODO Auto-generated method stub
			for(int i=0;i<warehouse.GetInventory().ProductList.size();i++) {
				if(warehouse.GetInventory().ProductList.get(i).equals(product)) {
					if(warehouse.GetInventory().ProductList.get(i).GetStock()>product.GetStock()
							|| warehouse.GetInventory().ProductList.get(i).GetStock()==product.GetStock()
							)
					warehouse.GetInventory().ProductList.get(i).SubStock(product.GetStock());
					else {
						warehouse.GetInventory().ProductList.get(i).SubStock(warehouse.GetInventory().ProductList.get(i).GetStock());
					}
				break;
				}
				
			}
		}
		
	

	private int DoesItHaveItSufficientQuantity(Warehouse warehouse,Product x) {
		// TODO Auto-generated method stub
		boolean GTx=warehouse.GetInventory().ProductList.contains(x);
		if(GTx==false) {
			return -1;
		}
		else {
			for(int i=0;i<warehouse.GetInventory().ProductList.size();i++) {
				if(warehouse.GetInventory().ProductList.get(i).equals(x)) {
					return warehouse.GetInventory().ProductList.get(i).GetStock();
				}
				
			}
		}
		return -1;
	}

	public ArrayList<Product> CheckInventory(Notifier other) {
		boolean flag=false;
		boolean Redflag=false;
		ArrayList<Product> Extras=new ArrayList<Product>();
		for(int i=0;i<other.GetNotice().size();i++) {
			if(wInventory.GetInventory().contains(other.GetNotice().get(i))) {
			for(int j=0;j<wInventory.GetInventory().size();i++) {
				if(wInventory.GetInventory().get(j).equals(other.GetNotice().get(i))){
					if(wInventory.GetInventory().get(j).inStock>other.GetNotice().get(i).GetStock()
							&&
							wInventory.GetInventory().get(j).inStock==other.GetNotice().get(i).GetStock()) {
						
					
					}
					else if(wInventory.GetInventory().get(j).inStock<other.GetNotice().get(i).GetStock()) {
						flag=true;
						Product x=other.GetNotice().get(i);
						x.AddToStock(other.GetNotice().get(i).GetStock()-wInventory.GetInventory().get(j).GetStock());
					Extras.add(x);
					
				}
				}
			
			
			}
			
		}
			else {
				Redflag=true;
			}
				Extras.add(other.GetNotice().get(i));
			}
		
		return Extras;
		
	
	}

	public String GetID() {
		// TODO Auto-generated method stub
		return this.wID;
	}

	public void ProcessOrders() {
		// TODO Auto-generated method stub
		for(int i=0;i<this.OrderToBeProcessed.size();i++) {
			
			if(this.GetInventory().GetInventory().contains(this.OrderToBeProcessed.get(i))) {
				
			for(int j=0;j<this.GetInventory().GetInventory().size();i++) {
					if(this.GetInventory().GetInventory().get(j).equals(this.OrderToBeProcessed.get(i))) {
						if(this.GetInventory().GetInventory().get(j).GetStock()>this.OrderToBeProcessed.get(i).GetStock()||
						this.GetInventory().GetInventory().get(j).GetStock()>this.OrderToBeProcessed.get(i).GetStock()) {
						this.GetInventory().GetInventory().get(j).SubStock(this.OrderToBeProcessed.get(i).GetStock());	
						}
						else if(this.GetInventory().GetInventory().get(j).GetStock()<this.OrderToBeProcessed.get(i).GetStock()) {
							this.GetInventory().GetInventory().get(j).SubStock(this.GetInventory().GetInventory().get(j).GetStock());
						}
					}
				}
			}
		}
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
}