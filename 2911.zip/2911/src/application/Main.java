package application;
	
import java.io.File;
import java.net.URL;

import Support.Database;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
	@Override
	public void start(Stage Stage1) {
		try {
			
			
			URL url = new File("C:/Users/Josef Haydn/Desktop/login.fxml").toURL();
			Parent root = FXMLLoader.load(url);
			Scene scene1=new Scene(root);
			Stage1.setScene(scene1);
			Stage1.show();
	
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
